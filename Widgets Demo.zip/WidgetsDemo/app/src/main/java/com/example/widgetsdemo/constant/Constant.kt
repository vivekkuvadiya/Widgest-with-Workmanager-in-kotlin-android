package com.example.widgetsdemo.constant

object Constant {

    const val KEY_DATA = "DATA"
    const val KEY_WIDGETS_ID = "WIDGET_ID"

}